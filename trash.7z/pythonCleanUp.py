import glob
import os

exit()

def check(filename):
	if filename.endswith('.erb'):
		newFilename = filename[:-4]+'.ERB'
		os.rename(filename, newFilename)
		print(':file renamed:' + filename)
	elif filename.endswith('.CSV'):
		newFilename = filename[:-4]+'.csv'
		os.rename(filename, newFilename)
		print(':file renamed:' + filename)
	elif filename.endswith('.TXT'):
		newFilename = filename[:-4]+'.txt'
		os.rename(filename, newFilename)
		print(':file renamed:' + filename)
	elif filename.endswith('.ERB'):
		pass
	elif filename.endswith('.csv'):
		pass
	elif filename.endswith('.txt'):
		pass
	elif filename.endswith('.khp'):
		pass
	elif filename.endswith('.webp'):
		pass
	elif filename.endswith('.png'):
		pass
	elif filename.endswith('.jpg'):
		pass
	elif filename.endswith('HOGE'):
		pass
	elif filename.endswith('.ERH'):
		pass
	elif filename == 'HOGE':
		pass
	else:
		print(':file ignored:' + filename)

import codecs

#from shiftjisbgone.py
def convert(x):
	if not x.endswith('.ERB'):
		return
	try:
		raw = open(x, 'rb').read(3)
		if raw == b'\xef\xbb\xbf':
			return #already utf-8-bom
		with codecs.open(x, mode='r', encoding='shift_jis') as file:
			lines = file.read()
		with codecs.open(x, mode='w', encoding='utf-8') as file:
			file.write(u'\uFEFF')
			for line in lines:
				file.write(line)
		print('converted: '+x)
	except UnicodeDecodeError as e:
		print('not shift-jis: '+x)


for x in glob.glob('**/*', recursive=True):
	if (os.path.isfile(x)):
		#check(x)
		convert(x)